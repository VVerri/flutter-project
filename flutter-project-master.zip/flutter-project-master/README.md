Membros do grupo:
Marcos Henrique Gaspari R.A. 2144174
Guilherme Mendes R.A. 2142414
Victor Silvano Verri R.A. 1914871


O trabalho desenvolvido é para utilização de uma mobiliaria que possui um estoque de produtos.
A tela inicial contem um login para acesso e caso não possua cadastro, temos a possibilidade um novo cadastro.
Após o login temos a home_page onde possui uma navBar com o e-mail utilizado para o login e um botão para sair da aplicação. Possui uma listagem com as categorias dos produtos que são elas: Cozinha, Escritório, Sala, Quarto e Banheiro.
Na tela seguinte temos uma listagem com os produtos relacionado com a categoria selecionada, onde possui os atributos de nome, valor e imagem.
Na seleção de um produto temos a página de detalhe do produto, onde contém uma botão para compra e um para selecionar a quantidade de itens. 

Bugs:

Não está filtrando os produtos após selecionar uma categoria.

Novas funcionalidades: 

Inserção de um produto.
Exclusão de um produto.
Edição de um produto.
Botão com a quantidade em estoque 

