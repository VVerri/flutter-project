import 'package:flutter/material.dart';
import 'widgets/app_widget.dart';

main() {
  runApp(AppWidget());
}
