class Category {
  int id;
  String icone;
  String nome;

  Category({
    required this.id,
    required this.icone,
    required this.nome,
  });
}
